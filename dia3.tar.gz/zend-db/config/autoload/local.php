<?php
 
return array(
    // Database credentials
    'db'=>array(
        'username'=>'root',
        'password'=>'root'
    )
);