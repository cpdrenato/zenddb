<?php

namespace Application\Model;

class Cliente{
	private $id;
	private $nome;
	private $cep;
	private $endereco;
	private $numero;
	private $complemento;
	private $cidade;
	private $bairro;
	private $estado;
	private $telefone;
	private $email;

	private function setId($id){
		$this->id = $id;
		return $this;

	}
	public function getId(){
		return $this->id;

	}
	private function setNome($nome){
		$this->id = $nome;
		return $this;

	}
	public function getNome(){
		return $this->nome;

	}
	private function setCep($cep){
		$this->id = $cep;
		return $this;

	}
	public function getCep(){
		return $this->cep;

	}
	private function setEndereco($endereco){
		$this->id = $endereco;
		return $this;

	}
	public function getEndereco(){
		return $this->endereco;

	}
	private function setNumero($numero){
		$this->id = $numero;
		return $this;

	}
	public function getNumero(){
		return $this->numero;

	}
	private function setComplemento($complemento){
		$this->id = $complemento;
		return $this;

	}
	public function getComplemento(){
		return $this->complemento;

	}
	private function setCidade($cidade){
		$this->id = $cidade;
		return $this;

	}
	public function getCidade(){
		return $this->cidade;

	}
	private function setBairro($bairro){
		$this->id = $bairro;
		return $this;

	}
	public function getBairro(){
		return $this->bairro;

	}
	private function setEstado($estado){
		$this->id = $estado;
		return $this;

	}
	public function getEstado(){
		return $this->estado;

	}
	private function setTelefone($telefone){
		$this->id = $telefone;
		return $this;

	}
	public function getTelefone(){
		return $this->telefone;

	}
	private function setEmail($email){
		$this->id = $email;
		return $this;

	}
	public function getEmail(){
		return $this->email;

	}

	public function exchangeArray(array $data){
		$this->setId($data['id'])
		->setNome($data['nome'])
		->setCep($data['cep'])
		->setEndereco($data['endereco'])
		->setNumero($data['numero'])
		->setComplemento($data['complemento'])
		->setCidade($data['cidade'])
		->setBairro($data['bairro'])
		->setEstado($data['estado'])
		->setTelefone($data['telefone'])
		->setEmail($data['email']);

	}
}