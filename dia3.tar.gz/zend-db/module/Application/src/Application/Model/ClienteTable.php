<?php

namespace Application\Model;

//use Zend\Mvc\Controller\AbstractActionController;
use Zend\Db\TableGateway\TableGateway;

class ClienteTable{

	private $tableGateway;

	public fucntion __construct(TableGateway $tableGateway){
		$this->tableGateway = $tableGateway;

	}
    
    public fucntion findAll(){
    	$resultSet = $this->tableGateway->select();
    	return $resultSet;
    }
}
