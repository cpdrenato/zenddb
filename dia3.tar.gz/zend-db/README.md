Aplicação Multi-Layout com Zend Framework 2
=======================

Sobre este exemplo
------------
Neste tutorial abordaremos um assunto muito interessante e muito simples de implementar do que se parece: 
trabalhar com múltiplos layouts com Zend Framework 2. Muitas pessoas quando começam a trabalhar com zf2, 
se perguntam: No zf2 só existe um layout para toda aplicação? Como faço para atribuir mais de um layout para os módulos?
Pois é, até conheço algumas pessoas que ficaram frustadas com zf2 porque acharam que ele não permite múltiplos layout, 
mas isto não é verdade, zf2 permite sim! E, há várias formas de fazer isto, e agora mostrarei uma das maneiras mais simples e práticas possíveis.
[Veja o link do tutorial](http://www.schoolofnet.com/2015/03/aplicacao-multi-layout-com-zend-framework-2/)